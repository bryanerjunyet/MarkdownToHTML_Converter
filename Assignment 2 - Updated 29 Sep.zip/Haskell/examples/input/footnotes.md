[^1]: My reference.
[^2]:Another reference.
[^3]:  The 2 spaces after the colon should be ignored
